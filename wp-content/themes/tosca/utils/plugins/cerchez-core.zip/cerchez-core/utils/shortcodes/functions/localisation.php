<?php
$strings = 'tinyMCE.addI18n({' . _WP_Editors::$mce_locale . ':{
	cerchezcore:{
		buttonTitle: "' . esc_js( __('Insert shortcode', 'cerchez-core') ) . '"
	}
}})';