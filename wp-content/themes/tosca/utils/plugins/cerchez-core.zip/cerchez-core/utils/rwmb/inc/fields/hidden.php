<?php
defined('ABSPATH') || exit;

if ( ! class_exists('RWMB_Hidden_Field') ) {

	class RWMB_Hidden_Field extends RWMB_Field {

		static function html( $meta, $field ) {
			return sprintf(
				'<input type="hidden" class="rwmb-hidden" name="%s" id="%s" value="%s" />',
				$field['field_name'],
				$field['id'],
				$meta
			);
		}
	}
}